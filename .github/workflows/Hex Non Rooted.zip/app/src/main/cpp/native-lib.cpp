#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <android/log.h>
#include <link.h>
#include <cstring>
#include <sys/uio.h>
#include <dirent.h>
#include <unistd.h>
#include <cstdio>
#include <cstdlib>

#define LOG_TAG "HexCore"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)

#define OFFSET_GAMEFACADE     0xA86D8D8
#define OFFSET_LOCALPLAYER    0xA86F580
#define OFFSET_VIEWMATRIX     0xB0F7948
#define OFFSET_TRANSFORM      0x190
#define OFFSET_HEALTH         0x1E4
#define OFFSET_TEAMID         0xC8

#define OFFSET_CURRENTGAME    0x0
#define OFFSET_MATCHGAME      0x8
#define OFFSET_ENTITYDICT     0x8
#define OFFSET_ENTRIESARR     0x18
#define OFFSET_ENTITYCOUNT    0x20
#define OFFSET_ENTRY_SIZE     0x18
#define OFFSET_PAWN           0x10

struct Vector3 { float x, y, z; };
struct Vector2 { float x, y; };
struct Matrix4x4 { float m[16]; };

static bool g_espActive = false;
static int g_gamePid = -1;
static std::mutex g_mtx;

bool ReadMemory(uintptr_t address, void* buffer, size_t size) {
    if (g_gamePid <= 0) return false;
    struct iovec local[1];
    struct iovec remote[1];
    local[0].iov_base = buffer;
    local[0].iov_len = size;
    remote[0].iov_base = (void*)address;
    remote[0].iov_len = size;
    ssize_t nread = process_vm_readv(g_gamePid, local, 1, remote, 1, 0);
    return nread == size;
}

template<typename T>
T Read(uintptr_t address) {
    T val{};
    if (address < 0x10000) return val;
    ReadMemory(address, &val, sizeof(T));
    return val;
}

int GetGamePid() {
    DIR* dir = opendir("/proc");
    if (!dir) return -1;
    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        if (entry->d_type == DT_DIR) {
            int pid = atoi(entry->d_name);
            if (pid <= 0) continue;
            char path[256];
            snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);
            FILE* f = fopen(path, "r");
            if (f) {
                char cmdline[256] = {0};
                fread(cmdline, 1, sizeof(cmdline) - 1, f);
                fclose(f);
                if (strstr(cmdline, "com.dts.freefiremax")) {
                    closedir(dir);
                    return pid;
                }
            }
        }
    }
    closedir(dir);
    return -1;
}

uintptr_t GetModuleBase(int pid, const char* moduleName) {
    char path[256];
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE* f = fopen(path, "r");
    if (!f) return 0;
    char line[512];
    uintptr_t base = 0;
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, moduleName)) {
            sscanf(line, "%lx-", &base);
            break;
        }
    }
    fclose(f);
    return base;
}

bool WorldToScreen(Vector3 pos, Vector2& screen, Matrix4x4& matrix, int width, int height) {
    float clipX = pos.x * matrix.m[0] + pos.y * matrix.m[4] + pos.z * matrix.m[8] + matrix.m[12];
    float clipY = pos.x * matrix.m[1] + pos.y * matrix.m[5] + pos.z * matrix.m[9] + matrix.m[13];
    float clipW = pos.x * matrix.m[3] + pos.y * matrix.m[7] + pos.z * matrix.m[11] + matrix.m[15];

    if (clipW < 0.1f) return false;

    float ndcX = clipX / clipW;
    float ndcY = clipY / clipW;

    screen.x = (width / 2.0f) * (ndcX + 1.0f);
    screen.y = (height / 2.0f) * (1.0f - ndcY);
    return true;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_dataflow_sys_service_NativeProvider_initEngine(JNIEnv* env, jclass) {
    std::lock_guard<std::mutex> lock(g_mtx);
    g_gamePid = GetGamePid();
    return g_gamePid > 0;
}

extern "C" JNIEXPORT void JNICALL
Java_com_dataflow_sys_service_NativeProvider_toggleEsp(JNIEnv* env, jclass, jboolean enable) {
    std::lock_guard<std::mutex> lock(g_mtx);
    g_espActive = enable;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_dataflow_sys_service_NativeProvider_getEspData(JNIEnv* env, jclass, jint screenW, jint screenH) {
    std::lock_guard<std::mutex> lock(g_mtx);
    if (!g_espActive || g_gamePid <= 0) return env->NewStringUTF("");

    uintptr_t base = GetModuleBase(g_gamePid, "libil2cpp.so");
    if (!base) return env->NewStringUTF("");

    uintptr_t localPlayer = Read<uintptr_t>(base + OFFSET_LOCALPLAYER);
    if (!localPlayer) return env->NewStringUTF("");
    
    int localTeam = Read<int>(localPlayer + OFFSET_TEAMID);

    uintptr_t ptrViewMatrix = Read<uintptr_t>(base + OFFSET_VIEWMATRIX);
    if (!ptrViewMatrix) return env->NewStringUTF("");
    Matrix4x4 viewMatrix = Read<Matrix4x4>(ptrViewMatrix);

    uintptr_t currentGame = Read<uintptr_t>(base + OFFSET_GAMEFACADE);
    if (!currentGame) return env->NewStringUTF("");
    
    uintptr_t matchGame = Read<uintptr_t>(currentGame + OFFSET_MATCHGAME);
    if (!matchGame) return env->NewStringUTF("");
    
    uintptr_t entityDict = Read<uintptr_t>(matchGame + OFFSET_ENTITYDICT);
    if (!entityDict) return env->NewStringUTF("");

    int entityCount = Read<int>(entityDict + OFFSET_ENTITYCOUNT);
    uintptr_t entriesArray = Read<uintptr_t>(entityDict + OFFSET_ENTRIESARR);
    
    if (!entriesArray || entityCount <= 0 || entityCount > 100) return env->NewStringUTF("");

    std::string result = "";
    char buffer[256];

    for (int i = 0; i < entityCount; i++) {
        uintptr_t entry = entriesArray + (i * OFFSET_ENTRY_SIZE);
        uintptr_t pawn = Read<uintptr_t>(entry + OFFSET_PAWN);
        if (!pawn || pawn == localPlayer) continue;

        int health = Read<int>(pawn + OFFSET_HEALTH);
        if (health <= 0 || health > 1000) continue;

        int team = Read<int>(pawn + OFFSET_TEAMID);
        if (team == localTeam) continue;

        uintptr_t transform = Read<uintptr_t>(pawn + OFFSET_TRANSFORM);
        if (!transform) continue;

        Vector3 footPos;
        footPos.x = Read<float>(transform + 0x38);
        footPos.y = Read<float>(transform + 0x3C);
        footPos.z = Read<float>(transform + 0x40);

        Vector3 headPos = footPos;
        headPos.y += 1.65f;

        Vector2 screenFoot, screenHead;
        if (WorldToScreen(footPos, screenFoot, viewMatrix, screenW, screenH) &&
            WorldToScreen(headPos, screenHead, viewMatrix, screenW, screenH)) {
            
            float height = screenFoot.y - screenHead.y;
            float width = height / 2.0f;
            float boxLeft = screenHead.x - (width / 2.0f);
            float boxTop = screenHead.y;

            snprintf(buffer, sizeof(buffer), "%.2f,%.2f,%.2f,%.2f;", boxLeft, boxTop, width, height);
            result += buffer;
        }
    }

    return env->NewStringUTF(result.c_str());
}
