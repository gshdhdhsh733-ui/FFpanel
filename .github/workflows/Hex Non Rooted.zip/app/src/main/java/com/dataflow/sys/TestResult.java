package com.dataflow.sys;

public class TestResult {
    public native boolean getOk();
    public native void setOk(boolean ok);
    public native byte[] getBytes();
    public native void setBytes(byte[] bytes);
    public native long getElapsedMs();
    public native void setElapsedMs(long ms);
    public native String getDetail();
    public native void setDetail(String detail);
    public native String getError();
    public native void setError(String error);
}
