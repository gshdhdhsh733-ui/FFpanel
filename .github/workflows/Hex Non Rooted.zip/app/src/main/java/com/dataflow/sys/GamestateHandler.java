package com.dataflow.sys;

public interface GamestateHandler {
    void onSnapshot(String snapshot);
}
