package golib;

public interface GamestateHandler {
    void onSnapshot(String snapshot);
}
