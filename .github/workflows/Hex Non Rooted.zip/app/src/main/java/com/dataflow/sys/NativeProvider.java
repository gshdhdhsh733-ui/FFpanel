package com.dataflow.sys;

public class NativeProvider {
    static {
        System.loadLibrary("gojni");
        System.loadLibrary("happcore");
    }

    public static native boolean initEngine();
    public static native String getEspData(int screenW, int screenH);
    public static native void toggleEsp(boolean enable);
    public static native void doAimbot(int screenW, int screenH);
}
