package com.dataflow.sys.service;

public class NativeProvider {
    static {
        System.loadLibrary("hexcore");
    }

    public static native boolean initEngine();
    public static native String getEspData(int screenW, int screenH);
    public static native void toggleEsp(boolean enable);
}
