package com.dataflow.sys;

public interface LogHandler {
    void onLog(int level, String message);
}
