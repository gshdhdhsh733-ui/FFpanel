package golib;

public interface LogHandler {
    void onLog(int level, String message);
}
