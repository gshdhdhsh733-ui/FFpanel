package golib;
public class Golib {
    public static native Session newSession(String configJson, FdProtector protector, EventHandler handler);
    public static native void setLogHandler(LogHandler handler);
    public static native void setMinLogLevel(String level);
    public static native void validateConfig(String configJson);
    public static native void touch();
}
