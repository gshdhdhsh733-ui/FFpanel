package com.dataflow.sys;

import com.dataflow.sys.service.NativeProvider;

import android.util.Log;
import fi.iki.elonen.NanoHTTPD;
import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import org.json.JSONObject;
import java.net.InetSocketAddress;

public class WebServer {
    private WebSocketServer wsServer;
    private NanoHTTPD httpServer;
    private static final String TAG = "HexWeb";

    public void start() {
        wsServer = new WebSocketServer(new InetSocketAddress(8081)) {
            @Override
            public void onOpen(WebSocket conn, ClientHandshake handshake) { Log.d(TAG, "Web Connected!"); }
            @Override
            public void onClose(WebSocket conn, int code, String reason, boolean remote) {}
            @Override
            public void onMessage(WebSocket conn, String message) {
                try {
                    JSONObject json = new JSONObject(message);
                    String action = json.getString("action");
                    boolean state = json.getBoolean("state");

                    if (action.equals("esp")) {
                        NativeProvider.toggleEsp(state);
                    } else if (action.equals("aimbot")) {
                        if (state) {
                            new Thread(() -> {
                                while(true) {
                                    NativeProvider.doAimbot(1080, 2340);
                                    try { Thread.sleep(50); } catch (Exception e) {}
                                }
                            }).start();
                        }
                    }
                } catch (Exception e) {}
            }
            @Override
            public void onError(WebSocket conn, Exception ex) {}
            @Override
            public void onStart() { Log.d(TAG, "WebSocket Started on 8081"); }
        };
        wsServer.start();

        httpServer = new NanoHTTPD(8080) {
            @Override
            public Response serve(IHTTPSession session) {
                String html = "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width, initial-scale=1.0'>" +
					"<style>" +
					"body { background: #121212; color: white; font-family: sans-serif; text-align: center; padding: 20px; }" +
					"h1 { color: #00FF00; }" +
					".card { background: #1e1e1e; border: 2px solid #00FF00; border-radius: 15px; padding: 20px; max-width: 400px; margin: auto; }" +
					".switch { position: relative; display: inline-block; width: 60px; height: 34px; margin: 15px; }" +
					".switch input { opacity: 0; width: 0; height: 0; }" +
					".slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 34px; }" +
					".slider:before { position: absolute; content: ''; height: 26px; width: 26px; left: 4px; bottom: 4px; background-color: white; transition: .4s; border-radius: 50%; }" +
					"input:checked + .slider { background-color: #00FF00; }" +
					"input:checked + .slider:before { transform: translateX(26px); }" +
					"</style></head><body>" +
					"<h1>HEX PANEL</h1>" +
					"<div class='card'>" +
					"<p id='status' style='color:red;'>Connecting...</p>" +
					"<div><span>ESP Box</span><label class='switch'><input type='checkbox' id='esp'><span class='slider'></span></label></div>" +
					"<div><span>Smooth Aimbot</span><label class='switch'><input type='checkbox' id='aim'><span class='slider'></span></label></div>" +
					"</div>" +
					"<script>" +
					"var ws = new WebSocket('ws://127.0.0.1:8081');" +
					"ws.onopen = () => { document.getElementById('status').innerText = 'CONNECTED'; document.getElementById('status').style.color = '#00FF00'; };" +
					"ws.onclose = () => { document.getElementById('status').innerText = 'DISCONNECTED'; document.getElementById('status').style.color = 'red'; };" +
					"document.getElementById('esp').addEventListener('change', function() { ws.send(JSON.stringify({action: 'esp', state: this.checked})); });" +
					"document.getElementById('aim').addEventListener('change', function() { ws.send(JSON.stringify({action: 'aimbot', state: this.checked})); });" +
					"</script></body></html>";
                return newFixedLengthResponse(html);
            }
        };

        try {
            httpServer.start();
        } catch (Exception e) {}
    }

    public void stop() {
        if (wsServer != null) wsServer.stop();
        if (httpServer != null) httpServer.stop();
    }
}
