package golib;

public class Session {
    public int refnum;
    public native void startTUN(int fd, int mtu, String ipv4, String ipv6, boolean enableIpv6, String dns);
    public native void checkConnection();
    public native void stopTUN();
    public native void close();
    public native void resetConnections();
    public native boolean getACL();
    public native void setACL(boolean enable);
    public native long getRxBytes();
    public native long getTxBytes();
    public native void runGamestate(String a, String b, GamestateHandler handler);
    public native TestResult testDNSOverTCP();
    public native TestResult testUDP();
}
