package com.dataflow.sys;

public interface FdProtector {
    boolean protect(int fd);
}
