package golib;

public interface FdProtector {
    boolean protect(int fd);
}
