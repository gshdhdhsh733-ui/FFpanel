package com.dataflow.sys;

import android.content.Intent;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.dataflow.sys.service.OverlayRender;
import com.dataflow.sys.service.TunnelGuard;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(60, 60, 60, 60);

        TextView tv = new TextView(this);
        tv.setText("Hex Non Rooted\nStatus: Ready");
        tv.setTextSize(24f);
        tv.setTextColor(0xFF00FF00);
        layout.addView(tv);

        Button btnOverlay = new Button(this);
        btnOverlay.setText("1. Allow Overlay Permission");
        btnOverlay.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (!Settings.canDrawOverlays(MainActivity.this)) {
						Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
						startActivity(intent);
					} else {
						Toast.makeText(MainActivity.this, "Already Granted", Toast.LENGTH_SHORT).show();
					}
				}
			});
        layout.addView(btnOverlay);

        Button btnStart = new Button(this);
        btnStart.setText("2. Start Hex Panel");
        btnStart.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (Settings.canDrawOverlays(MainActivity.this)) {
						ContextCompat.startForegroundService(MainActivity.this, new Intent(MainActivity.this, OverlayRender.class));
						startVpn();
					} else {
						Toast.makeText(MainActivity.this, "Overlay Permission Required", Toast.LENGTH_SHORT).show();
					}
				}
			});
        layout.addView(btnStart);

        setContentView(layout);
    }

    private void startVpn() {
        Intent intent = VpnService.prepare(this);
        if (intent != null) {
            startActivityForResult(intent, 1);
        } else {
            ContextCompat.startForegroundService(this, new Intent(this, TunnelGuard.class));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            ContextCompat.startForegroundService(this, new Intent(this, TunnelGuard.class));
        }
    }
}
