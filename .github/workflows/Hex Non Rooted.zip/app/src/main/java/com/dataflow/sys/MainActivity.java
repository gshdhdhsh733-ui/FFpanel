package com.dataflow.sys;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    private WebServer webServer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        webServer = new WebServer();
        webServer.start();

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(60, 60, 60, 60);
        layout.setBackgroundColor(Color.parseColor("#121212"));

        TextView tv = new TextView(this);
        tv.setText("HEX PANEL ACTIVE");
        tv.setTextSize(28f);
        tv.setTextColor(Color.parseColor("#00FF00"));
        tv.setGravity(Gravity.CENTER);
        layout.addView(tv);

        TextView subTv = new TextView(this);
        subTv.setText("Open Chrome and visit:\nhttp://127.0.0.1:8080");
        subTv.setTextSize(16f);
        subTv.setTextColor(Color.WHITE);
        subTv.setGravity(Gravity.CENTER);
        subTv.setPadding(0, 20, 0, 50);
        layout.addView(subTv);

        Button btnOverlay = new Button(this);
        btnOverlay.setText("START GAME OVERLAY & VPN");
        btnOverlay.setBackgroundColor(Color.parseColor("#00FF00"));
        btnOverlay.setTextColor(Color.BLACK);
        btnOverlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Settings.canDrawOverlays(MainActivity.this)) {
                    ContextCompat.startForegroundService(MainActivity.this, new Intent(MainActivity.this, OverlayRender.class));
                    startVpn();
                } else {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                }
            }
        });
        layout.addView(btnOverlay);

        setContentView(layout);
    }

    private void startVpn() {
        Intent intent = VpnService.prepare(this);
        if (intent != null) {
            startActivityForResult(intent, 1);
        } else {
            ContextCompat.startForegroundService(this, new Intent(this, TunnelGuard.class));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            ContextCompat.startForegroundService(this, new Intent(this, TunnelGuard.class));
        }
    }

    @Override
    protected void onDestroy() {
        if (webServer != null) webServer.stop();
        super.onDestroy();
    }
}
