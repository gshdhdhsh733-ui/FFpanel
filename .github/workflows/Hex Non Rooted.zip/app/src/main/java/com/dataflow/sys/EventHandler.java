package com.dataflow.sys;

public interface EventHandler {
    void onConnected();
    void onDisconnected(String error);
    void onReconnecting(int attempt, String reason);
}
