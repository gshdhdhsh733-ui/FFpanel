package com.dataflow.sys;

import com.dataflow.sys.service.NativeProvider;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.IBinder;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;
import androidx.core.app.NotificationCompat;

public class OverlayRender extends Service {
    private WindowManager wm;
    private SurfaceView espView;
    private Thread renderThread;
    private boolean isRunning = false;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(1, getNotification());

        NativeProvider.initEngine();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        setupEspView();
    }

    private void setupEspView() {
        espView = new SurfaceView(this);
        WindowManager.LayoutParams espParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        );

        espView.getHolder().addCallback(new SurfaceHolder.Callback() {
				@Override
				public void surfaceCreated(SurfaceHolder holder) {
					isRunning = true;
					renderThread = new Thread(new Runnable() {
							@Override
							public void run() {
								Paint paint = new Paint();
								paint.setColor(Color.parseColor("#00FF00"));
								paint.setStyle(Paint.Style.STROKE);
								paint.setStrokeWidth(4f);
								paint.setAntiAlias(true);

								while (isRunning) {
									Canvas canvas = holder.lockCanvas();
									if (canvas == null) continue;

									canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
									String data = NativeProvider.getEspData(canvas.getWidth(), canvas.getHeight());

									if (!data.isEmpty()) {
										String[] boxes = data.split(";");
										for (String box : boxes) {
											if (box.isEmpty()) continue;
											String[] p = box.split(",");
											if (p.length == 4) {
												float x = Float.parseFloat(p[0]);
												float y = Float.parseFloat(p[1]);
												float w = Float.parseFloat(p[2]);
												float h = Float.parseFloat(p[3]);
												canvas.drawRect(x, y, x + w, y + h, paint);
											}
										}
									}
									holder.unlockCanvasAndPost(canvas);
									try { Thread.sleep(16); } catch (InterruptedException e) {}
								}
							}
						});
					renderThread.start();
				}
				@Override
				public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}
				@Override
				public void surfaceDestroyed(SurfaceHolder holder) {
					isRunning = false;
					try { renderThread.join(); } catch (Exception e) {}
				}
			});
        wm.addView(espView, espParams);
    }

    private Notification getNotification() {
        String ch = "overlay_channel";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(ch, "Overlay", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, ch);
        b.setContentTitle("Hex Non Rooted").setContentText("Overlay Running").setSmallIcon(android.R.drawable.ic_menu_view);
        return b.build();
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        if (espView != null) {
            wm.removeView(espView);
        }
        super.onDestroy();
    }
}
