package com.dataflow.sys.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import androidx.core.app.NotificationCompat;

public class OverlayRender extends Service {
    private WindowManager wm;
    private SurfaceView espView;
    private Thread renderThread;
    private boolean isRunning = false;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(1, getNotification());

        NativeProvider.initEngine();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        setupEspView();
        setupFloatingMenu();
    }

    private void setupEspView() {
        espView = new SurfaceView(this);
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        );

        espView.getHolder().addCallback(new SurfaceHolder.Callback() {
				@Override
				public void surfaceCreated(SurfaceHolder holder) {
					isRunning = true;
					renderThread = new Thread(new Runnable() {
							@Override
							public void run() {
								Paint paint = new Paint();
								paint.setColor(Color.GREEN);
								paint.setStyle(Paint.Style.STROKE);
								paint.setStrokeWidth(4f);
								paint.setAntiAlias(true);

								while (isRunning) {
									Canvas canvas = holder.lockCanvas();
									if (canvas == null) continue;

									canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
									String data = NativeProvider.getEspData(canvas.getWidth(), canvas.getHeight());

									if (!data.isEmpty()) {
										String[] boxes = data.split(";");
										for (String box : boxes) {
											if (box.isEmpty()) continue;
											String[] p = box.split(",");
											if (p.length == 4) {
												float x = Float.parseFloat(p[0]);
												float y = Float.parseFloat(p[1]);
												float w = Float.parseFloat(p[2]);
												float h = Float.parseFloat(p[3]);
												canvas.drawRect(x, y, x + w, y + h, paint);
											}
										}
									}
									holder.unlockCanvasAndPost(canvas);
									try { Thread.sleep(16); } catch (InterruptedException e) {}
								}
							}
						});
					renderThread.start();
				}
				@Override
				public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}
				@Override
				public void surfaceDestroyed(SurfaceHolder holder) {
					isRunning = false;
					try { renderThread.join(); } catch (Exception e) {}
				}
			});
        wm.addView(espView, params);
    }

    private void setupFloatingMenu() {
        LinearLayout menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setBackgroundColor(Color.parseColor("#CC000000"));
        menu.setPadding(30, 30, 30, 30);

        TextView tv = new TextView(this);
        tv.setText("HEX PANEL");
        tv.setTextColor(Color.GREEN);
        tv.setTextSize(18f);
        menu.addView(tv);

        Switch espSwitch = new Switch(this);
        espSwitch.setText("ESP Box");
        espSwitch.setTextColor(Color.WHITE);
        espSwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
					NativeProvider.toggleEsp(isChecked);
				}
			});
        menu.addView(espSwitch);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 100;
        params.y = 200;

        menu.setOnTouchListener(new View.OnTouchListener() {
				private int initialX, initialY;
				private float initialTouchX, initialTouchY;

				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							initialX = params.x;
							initialY = params.y;
							initialTouchX = event.getRawX();
							initialTouchY = event.getRawY();
							return true;
						case MotionEvent.ACTION_MOVE:
							params.x = initialX + (int) (event.getRawX() - initialTouchX);
							params.y = initialY + (int) (event.getRawY() - initialTouchY);
							wm.updateViewLayout(menu, params);
							return true;
					}
					return false;
				}
			});

        wm.addView(menu, params);
    }

    private Notification getNotification() {
        String ch = "overlay_channel";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(ch, "Overlay", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, ch);
        b.setContentTitle("Hex Non Rooted").setContentText("Overlay Running").setSmallIcon(android.R.drawable.ic_menu_view);
        return b.build();
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        if (espView != null) {
            wm.removeView(espView);
        }
        super.onDestroy();
    }
}
