package com.dataflow.sys.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import androidx.core.app.NotificationCompat;

public class TunnelGuard extends VpnService {
    private ParcelFileDescriptor tun;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(2, getNotification());
        if (tun == null) {
            Builder builder = new Builder();
            builder.setSession("Hex Non Rooted Tunnel");
            builder.addAddress("10.0.0.2", 32);
            builder.addRoute("0.0.0.0", 0);
            builder.addDnsServer("1.1.1.1");
            tun = builder.establish();
        }
        return START_STICKY;
    }

    private Notification getNotification() {
        String ch = "vpn_channel";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(ch, "VPN", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, ch);
        b.setContentTitle("Hex Non Rooted").setContentText("Tunnel Active").setSmallIcon(android.R.drawable.ic_lock_lock);
        return b.build();
    }

    @Override
    public void onDestroy() {
        if (tun != null) {
            try { tun.close(); } catch (Exception e) {}
        }
        super.onDestroy();
    }
}
