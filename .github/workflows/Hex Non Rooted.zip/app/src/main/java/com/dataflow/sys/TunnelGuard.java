package com.dataflow.sys;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import androidx.core.app.NotificationCompat;

public class TunnelGuard extends VpnService {
    private ParcelFileDescriptor tun;
    private static final String TAG = "HexTunnel";

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(2, getNotification());

        if (tun == null) {
            try {
                Builder builder = new Builder();
                builder.setSession("Hex Non Rooted Tunnel");
                builder.addAddress("10.0.0.2", 32);
                builder.addRoute("0.0.0.0", 0);
                builder.addDnsServer("1.1.1.1");

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    builder.addAllowedApplication("com.dts.freefiremax");
                    builder.addAllowedApplication("com.dts.freefireth");
                }

                tun = builder.establish();

                if (tun != null) {
                    Golib.setLogHandler(new LogHandler() {
							@Override
							public void onLog(int level, String message) {
								Log.d(TAG, "GoLog: " + message);
							}
						});

                    String configJson = "{"
                        + "\"log\": {\"level\": \"info\"},"
                        + "\"inbounds\": [{\"type\": \"tun\", \"tag\": \"tun-in\", \"interface_name\": \"tun0\", \"inet4_address\": \"10.0.0.2/32\", \"auto_route\": true, \"stack\": \"gvisor\"}],"
                        + "\"outbounds\": [{"
                        + "  \"type\": \"hysteria2\","
                        + "  \"tag\": \"proxy\","
                        + "  \"server\": \"160.22.109.156\","
                        + "  \"server_port\": 443,"
                        + "  \"password\": \"bhai123\","
                        + "  \"obfs\": {\"type\": \"salamander\", \"password\": \"obfs123\"},"
                        + "  \"tls\": {\"enabled\": true, \"server_name\": \"bing.com\", \"alpn\": [\"h3\"], \"insecure\": true, \"utls\": {\"enabled\": true, \"fingerprint\": \"chrome\"}}"
                        + "}]"
                        + "}";

                    Golib.validateConfig(configJson);
                    Golib.setMinLogLevel("info");

                    FdProtector protector = new FdProtector() {
                        @Override
                        public boolean protect(int fd) {
                            return TunnelGuard.this.protect(fd);
                        }
                    };

                    EventHandler handler = new EventHandler() {
                        @Override
                        public void onConnected() { Log.d(TAG, "Tunnel Connected!"); }
                        @Override
                        public void onDisconnected(String error) { Log.e(TAG, "Disconnected: " + error); }
                        @Override
                        public void onReconnecting(int attempt, String reason) { Log.d(TAG, "Reconnecting..."); }
                    };

                    Session session = Golib.newSession(configJson, protector, handler);

                    if (session != null) {
                        session.startTUN(tun.getFd(), 1500, "10.0.0.2", "2001:db8::1", false, "1.1.1.1");
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "VPN Error: " + e.getMessage());
            }
        }
        return START_STICKY;
    }

    private Notification getNotification() {
        String channelId = "vpn_channel";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(channelId, "VPN", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, channelId);
        b.setContentTitle("Hex Non Rooted").setContentText("Tunnel Active").setSmallIcon(android.R.drawable.ic_lock_lock);
        return b.build();
    }

    @Override
    public void onDestroy() {
        if (tun != null) {
            try { tun.close(); } catch (Exception e) {}
        }
        super.onDestroy();
    }
}
