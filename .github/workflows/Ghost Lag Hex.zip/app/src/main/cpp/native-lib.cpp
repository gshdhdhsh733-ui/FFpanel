#include <jni.h>
#include <string>
#include <android/log.h>
#include <linux/if_tun.h>
#include <unistd.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <arpa/inet.h>
#include <thread>
#include <mutex>
#include <chrono>

static int g_tun_fd = -1;
static std::string g_data = "";
static std::mutex g_mtx;
static bool g_running = false;
static bool g_drop = false;

const unsigned char KEY = 0x5F; // Tera XOR Key

void ReadLoop() {
    unsigned char buf[4096];
    while (g_running) {
        int len = read(g_tun_fd, buf, sizeof(buf));
        if (len > 0) {
            if (g_drop) continue; // Lag Switch Packet Drop

            struct iphdr* ip = (struct iphdr*)buf;
            if (ip->protocol == IPPROTO_UDP) {
                struct udphdr* udp = (struct udphdr*)(buf + (ip->ihl * 4));
                if (ntohs(udp->dest) == 10015) {
                    unsigned char* payload = buf + (ip->ihl * 4) + sizeof(struct udphdr);
                    int plen = ntohs(udp->len) - sizeof(struct udphdr);
                    if (plen > 50) {
                        for (int i = 0; i < plen; i++) payload[i] ^= KEY;
                        
                        if (plen >= 0x1C) {
                            float x = *(float*)(payload + 0x10);
                            float y = *(float*)(payload + 0x14);
                            float z = *(float*)(payload + 0x18);
                            
                            if (x > 10 && x < 8000 && y > -50 && y < 500 && z > 10 && z < 8000) {
                                std::lock_guard<std::mutex> lock(g_mtx);
                                char b[64];
                                snprintf(b, sizeof(b), "%.1f,%.1f;", x, z);
                                g_data += b;
                            }
                        }
                    }
                }
            }
        }
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_ghost_hex_NativeProvider_startEngine(JNIEnv* env, jclass, jint fd) {
    if (g_running) return;
    g_tun_fd = fd;
    g_running = true;
    std::thread(ReadLoop).detach();
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_ghost_hex_NativeProvider_getEspData(JNIEnv* env, jclass) {
    std::lock_guard<std::mutex> lock(g_mtx);
    std::string res = g_data;
    g_data = "";
    return env->NewStringUTF(res.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_ghost_hex_NativeProvider_triggerLag(JNIEnv* env, jclass) {
    std::thread([]{
        g_drop = true;
        std::this_thread::sleep_for(std::chrono::milliseconds(250));
        g_drop = false;
    }).detach();
}
