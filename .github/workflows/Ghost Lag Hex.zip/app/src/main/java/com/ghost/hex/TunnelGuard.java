package com.ghost.hex;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;

public class TunnelGuard extends VpnService {
    private ParcelFileDescriptor tun;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(2, getNotification());

        if (tun == null) {
            Builder builder = new Builder();
            builder.setSession("Ghost Lag Hex Tunnel");
            builder.addAddress("10.0.0.2", 32);
            builder.addRoute("0.0.0.0", 0);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.addAllowedApplication("com.dts.freefiremax");
            }

            tun = builder.establish();

            if (tun != null) {
                NativeProvider.startEngine(tun.getFd());
            }
        }
        return START_STICKY;
    }

    private Notification getNotification() {
        String ch = "vpn_ch";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(ch, "VPN", NotificationManager.IMPORTANCE_LOW));
        }

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            b = new Notification.Builder(this, ch);
        } else {
            b = new Notification.Builder(this);
        }

        b.setContentTitle("Ghost Lag Hex");
        b.setContentText("Tunnel Active");
        b.setSmallIcon(android.R.drawable.ic_lock_lock);
        return b.build();
    }

    @Override
    public void onDestroy() {
        if (tun != null) {
            try { tun.close(); } catch (Exception e) {}
        }
        super.onDestroy();
    }
}
