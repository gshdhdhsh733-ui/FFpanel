package com.ghost.hex;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(0xFF090B12);
        layout.setPadding(50, 50, 50, 50);

        TextView title = new TextView(this);
        title.setText("GHOST LAG HEX");
        title.setTextColor(0xFF00F5D4);
        title.setTextSize(32f);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 60);
        layout.addView(title);

        Button btn = new Button(this);
        btn.setText("START PANEL");
        btn.setTextSize(18f);
        btn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					checkPermissions();
				}
			});
        layout.addView(btn);

        setContentView(layout);
    }

    private void checkPermissions() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            Toast.makeText(this, "Grant Overlay Permission", Toast.LENGTH_SHORT).show();
            return;
        }

        startService(new Intent(this, OverlayRender.class));

        Intent vpnIntent = VpnService.prepare(this);
        if (vpnIntent != null) {
            startActivityForResult(vpnIntent, 1);
        } else {
            startService(new Intent(this, TunnelGuard.class));
        }
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            startService(new Intent(this, TunnelGuard.class));
        } else {
            Toast.makeText(this, "VPN Permission Denied", Toast.LENGTH_SHORT).show();
        }
    }
}
