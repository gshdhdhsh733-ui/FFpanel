package com.ghost.hex;

public class NativeProvider {
    static {
        // gojni library load karne ki koshish
        try {
            System.loadLibrary("gojni");
        } catch (UnsatisfiedLinkError e) {
            e.printStackTrace();
        }
        // hexcore library load karne ki koshish (jo GitHub par build hoti hai)
        try {
            System.loadLibrary("hexcore");
        } catch (UnsatisfiedLinkError e) {
            e.printStackTrace();
        }
    }

    public static native void startEngine(int tunFd);
    public static native String getEspData();
    public static native void triggerLag();
}