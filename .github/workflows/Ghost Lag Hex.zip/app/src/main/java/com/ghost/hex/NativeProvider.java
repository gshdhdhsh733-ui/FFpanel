package com.ghost.hex;

public class NativeProvider {
    static {
        System.loadLibrary("gojni");
        System.loadLibrary("hexcore");
    }

    public static native void startEngine(int tunFd);
    public static native String getEspData();
    public static native void triggerLag();
}
