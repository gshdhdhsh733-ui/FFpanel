package com.ghost.hex;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayRender extends Service {
    private WindowManager wm;
    private View menuView;
    private SurfaceView radarView;
    private WindowManager.LayoutParams menuParams;
    private volatile boolean isRunning = false; // Crash fix

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        isRunning = true;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        setupRadar();
        setupMenu();
    }

    private void setupRadar() {
        radarView = new SurfaceView(this);
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        );
        wm.addView(radarView, params);

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (isRunning) { // Loop flag check
                    Canvas canvas = radarView.getHolder().lockCanvas();
                    if (canvas != null) {
                        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
                        Paint p = new Paint();
                        p.setColor(Color.GREEN);
                        p.setStyle(Paint.Style.STROKE);
                        p.setStrokeWidth(5f);
                        
                        float cx = canvas.getWidth() / 2f;
                        float cy = canvas.getHeight() / 2f;
                        canvas.drawCircle(cx, cy, 10f, p);

                        String data = NativeProvider.getEspData();
                        if (!data.isEmpty()) {
                            String[] points = data.split(";");
                            for (String pt : points) {
                                if (pt.isEmpty()) continue;
                                String[] coords = pt.split(",");
                                if (coords.length == 2) {
                                    float x = Float.parseFloat(coords[0]);
                                    float z = Float.parseFloat(coords[1]);
                                    
                                    float screenX = cx + (x % 300);
                                    float screenY = cy + (z % 300);
                                    
                                    p.setColor(Color.RED);
                                    p.setStyle(Paint.Style.FILL);
                                    canvas.drawCircle(screenX, screenY, 15f, p);
                                }
                            }
                        }
                        radarView.getHolder().unlockCanvasAndPost(canvas);
                    }
                    try { Thread.sleep(30); } catch (Exception e) {}
                }
            }
        }).start();
    }

    private void setupMenu() {
        LinearLayout menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setBackgroundColor(Color.parseColor("#E6000000"));
        menu.setPadding(30, 30, 30, 30);

        TextView title = new TextView(this);
        title.setText("GHOST LAG HEX");
        title.setTextColor(Color.GREEN);
        title.setTextSize(20f);
        menu.addView(title);

        Button lagBtn = new Button(this);
        lagBtn.setText("TRIGGER LAG");
        lagBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NativeProvider.triggerLag();
            }
        });
        menu.addView(lagBtn);

        Button closeBtn = new Button(this);
        closeBtn.setText("CLOSE");
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopSelf();
            }
        });
        menu.addView(closeBtn);

        menuParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        menuParams.gravity = Gravity.TOP | Gravity.START;
        menuParams.x = 100;
        menuParams.y = 200;

        menu.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = menuParams.x; initialY = menuParams.y;
                        initialTouchX = event.getRawX(); initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        menuParams.x = initialX + (int) (event.getRawX() - initialTouchX);
                        menuParams.y = initialY + (int) (event.getRawY() - initialTouchY);
                        wm.updateViewLayout(menu, menuParams);
                        return true;
                }
                return false;
            }
        });
        menuView = menu;
        wm.addView(menuView, menuParams);
    }

    @Override
    public void onDestroy() {
        isRunning = false; // Thread ko stop karo
        super.onDestroy();
        if (menuView != null) wm.removeView(menuView);
        if (radarView != null) wm.removeView(radarView);
    }
}