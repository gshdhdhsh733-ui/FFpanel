#include "cheat_engine.h"
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cerrno>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ptrace.h>
#include <sys/uio.h>
#include <sys/wait.h>

namespace ff {
bool CheatEngine::attach(const std::string& pkg) {
    DIR* d = opendir("/proc"); if (!d) return false;
    dirent* e;
    while ((e = readdir(d))) {
        if (e->d_type != DT_DIR) continue;
        long pid = strtol(e->d_name, nullptr, 10);
        if (pid <= 0) continue;
        char path[256], cmd[256] = {};
        snprintf(path, sizeof(path), "/proc/%ld/cmdline", pid);
        int fd = open(path, O_RDONLY | O_CLOEXEC);
        if (fd >= 0) {
            read(fd, cmd, sizeof(cmd) - 1); close(fd);
            if (strstr(cmd, pkg.c_str())) { info_.pid = (int)pid; break; }
        }
    }
    closedir(d);
    if (info_.pid <= 0) return false;

    system("su -c 'setenforce 0'");
    if (ptrace(PTRACE_ATTACH, info_.pid, nullptr, nullptr) < 0) return false;
    int st = 0; waitpid(info_.pid, &st, 0);

    char mp[64]; snprintf(mp, sizeof(mp), "/proc/%d/mem", info_.pid);
    mem_fd_ = open(mp, O_RDWR | O_CLOEXEC);
    if (mem_fd_ < 0) { ptrace(PTRACE_DETACH, info_.pid, nullptr, nullptr); return false; }

    snprintf(mp, sizeof(mp), "/proc/%d/maps", info_.pid);
    FILE* f = fopen(mp, "r"); char line[512];
    while (f && fgets(line, sizeof(line), f)) {
        if (strstr(line, "libil2cpp.so")) { sscanf(line, "%lx-", &info_.base); break; }
    }
    if (f) fclose(f);
    attached_ = true; return true;
}
void CheatEngine::detach() {
    if (mem_fd_ >= 0) { close(mem_fd_); mem_fd_ = -1; }
    if (attached_) { ptrace(PTRACE_DETACH, info_.pid, nullptr, nullptr); attached_ = false; }
}
bool CheatEngine::alive() const { return attached_ && kill(info_.pid, 0) == 0; }
bool CheatEngine::read(uintptr_t addr, void* buf, size_t size) {
    if (mem_fd_ < 0) return false;
    iovec l{ buf, size }, r{ (void*)addr, size };
    if (process_vm_readv(info_.pid, &l, 1, &r, 1, 0) == (ssize_t)size) return true;
    return pread(mem_fd_, buf, size, addr) == (ssize_t)size;
}
}
