package com.example.panel;

import android.content.Context;
import android.net.LocalSocket;
import android.net.LocalSocketAddress;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;

public final class EngineClient {
    private static final String SOCK = "/data/local/tmp/ffd.sock";
    private static LocalSocket sock;
    private static DataInputStream in;
    private static DataOutputStream out;
    private static volatile boolean ready;

    public static boolean attach(Context ctx, String pkg) {
        if (ready) return true;
        File bin = EngineLoader.ensureDaemon(ctx);
        if (bin == null) return false;

        try {
            Runtime.getRuntime().exec(new String[]{"su", "-c", bin.getAbsolutePath()});
        } catch (Exception e) { return false; }

        for (int i = 0; i < 60; i++) {
            try { Thread.sleep(100); } catch (Exception e) {}
            if (!new File(SOCK).exists()) continue;
            try {
                LocalSocket s = new LocalSocket();
                s.connect(new LocalSocketAddress(SOCK, LocalSocketAddress.Namespace.FILESYSTEM));
                sock = s; in = new DataInputStream(s.getInputStream()); out = new DataOutputStream(s.getOutputStream());
                break;
            } catch (Exception e) {}
        }
        if (sock == null) return false;

        try {
            byte[] pkgBytes = pkg.getBytes("UTF-8");
            out.writeInt(1); out.writeInt(pkgBytes.length); out.write(pkgBytes); out.flush();
            if (in.readInt() != 1) return false;
            ready = true;
            return true;
        } catch (Exception e) { return false; }
    }

    public static void flag(int slot, boolean on) {
        if (!ready) return;
        try { out.writeInt(2); out.writeInt(8); out.writeInt(slot); out.writeInt(on?1:0); out.flush(); in.readInt(); } catch (Exception e) {}
    }

    public static float[] pull() {
        if (!ready) return new float[0];
        try {
            out.writeInt(4); out.writeInt(0); out.flush();
            int count = in.readInt();
            if (count <= 0 || count > 512) return new float[0];
            float[] buf = new float[count];
            for (int i=0; i<count; i++) buf[i] = in.readFloat();
            return buf;
        } catch (Exception e) { return new float[0]; }
    }

    public static void shutdown() {
        if (ready) { try { out.writeInt(5); out.writeInt(0); out.flush(); in.readInt(); } catch (Exception e) {} }
        ready = false;
        try { if (sock != null) sock.close(); } catch (Exception e) {}
        sock = null;
    }
}
