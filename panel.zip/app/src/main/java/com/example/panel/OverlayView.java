package com.example.panel;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class OverlayView extends View {
    private final Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fovPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private volatile float[] targets = new float[0];

    public OverlayView(Context ctx) {
        super(ctx);
        boxPaint.setStyle(Paint.Style.STROKE); 
        boxPaint.setStrokeWidth(3f); 
        boxPaint.setColor(0xFFFF0000);

        linePaint.setStyle(Paint.Style.STROKE); 
        linePaint.setStrokeWidth(2f); 
        linePaint.setColor(0xFFFF0000);

        textPaint.setColor(Color.WHITE); 
        textPaint.setTextSize(30f);

        fovPaint.setStyle(Paint.Style.STROKE); 
        fovPaint.setStrokeWidth(3f); 
        fovPaint.setColor(0x88FFFFFF); 
    }

    public void updateTargets(float[] pts) { targets = pts; postInvalidate(); }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() * 0.5f;
        float cy = getHeight() * 0.5f;
        float bottom = getHeight();

        if (PanelService.sShowFov) canvas.drawCircle(cx, cy, PanelService.sFovRadius, fovPaint);

        if (targets == null) return;
        for (int i = 0; i < targets.length; i += 2) {
            float x = targets[i], y = targets[i+1];
            if (PanelService.sAimLine) canvas.drawLine(cx, bottom, x, y, linePaint);
            if (PanelService.sBoxes) canvas.drawRect(x - 70f, y - 200f, x + 70f, y + 40f, boxPaint);
            canvas.drawText("BOT", x - 30f, y - 210f, textPaint);
        }
    }
}
