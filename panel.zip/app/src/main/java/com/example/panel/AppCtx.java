package com.example.panel;

import android.app.Application;

public class AppCtx extends Application {
    private static AppCtx sInst;
    @Override public void onCreate() { super.onCreate(); sInst = this; }
    public static AppCtx get() { return sInst; }
}
