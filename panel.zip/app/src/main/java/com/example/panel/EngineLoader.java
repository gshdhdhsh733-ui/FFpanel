package com.example.panel;

import android.content.Context;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public final class EngineLoader {
    public static synchronized File ensureDaemon(Context ctx) {
        File src = new File(ctx.getApplicationInfo().nativeLibraryDir, "libengine_daemon.so");
        File dst = new File(ctx.getFilesDir(), "engine_daemon");

        if (dst.exists()) dst.delete();

        try {
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(dst);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            out.close();
        } catch (Exception e) {
            return null;
        }

        dst.setExecutable(true, false);
        return dst;
    }
}
