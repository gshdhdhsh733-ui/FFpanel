package com.example.myapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQ = 10;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        showHome();
    }

    private void showHome() {
        FrameLayout root = new FrameLayout(this);

        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.bg_main);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(bg, new FrameLayout.LayoutParams(
						 FrameLayout.LayoutParams.MATCH_PARENT,
						 FrameLayout.LayoutParams.MATCH_PARENT));

        int screenHeight = getResources().getDisplayMetrics().heightPixels;

        View invisibleStart = new View(this);
        FrameLayout.LayoutParams startLp = new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.MATCH_PARENT, dp(70)); 
        startLp.gravity = Gravity.TOP;
        startLp.topMargin = (int) (screenHeight * 0.39); 
        invisibleStart.setLayoutParams(startLp);
        invisibleStart.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					startPanel();
				}
			});
        root.addView(invisibleStart);

        View invisibleStop = new View(this);
        FrameLayout.LayoutParams stopLp = new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.MATCH_PARENT, dp(70)); 
        stopLp.gravity = Gravity.TOP;
        stopLp.topMargin = (int) (screenHeight * 0.49); 
        invisibleStop.setLayoutParams(stopLp);
        invisibleStop.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					stopService(new Intent(MainActivity.this, PanelService.class));
					Toast.makeText(MainActivity.this, "Panel stopped", Toast.LENGTH_SHORT).show();
				}
			});
        root.addView(invisibleStop);

        setContentView(root);
    }

    private void startPanel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
			&& !Settings.canDrawOverlays(this)) {
            Intent permission = new Intent(
				Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
				Uri.parse("package:" + getPackageName()));
            startActivityForResult(permission, OVERLAY_REQ);
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Pro Mode Root");
        builder.setMessage("Checking Root Access...\nPlease wait.");
        builder.setCancelable(false);
        final AlertDialog dialog = builder.create();
        dialog.show();

        new Thread(new Runnable() {
				@Override
				public void run() {
					boolean isRooted = checkRoot();
					boolean isGameRunning = checkGameProcess();

					new Handler(Looper.getMainLooper()).post(new Runnable() {
							@Override
							public void run() {
								if (isRooted) {
									dialog.setMessage("✔ Root Access Granted!\n\nConnecting to Game...");
								} else {
									dialog.setMessage("⚠ Root Not Found!\n\nConnecting anyway...");
								}

								new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
										@Override
										public void run() {
											// ASLI GAME CHECK YAHAN DIKHEGA
											if (isGameRunning) {
												dialog.setMessage("✔ Root Granted\n✔ Game Connected!\n\nStarting Panel...");
											} else {
												dialog.setMessage("✔ Root Granted\n❌ Game Not Found!\n(Please open Free Fire First)\n\nStarting Panel...");
											}

											new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
													@Override
													public void run() {
														dialog.dismiss();
														Intent service = new Intent(MainActivity.this, PanelService.class);
														if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
															startForegroundService(service);
														} else {
															startService(service);
														}
														Toast.makeText(MainActivity.this, "Panel Activated", Toast.LENGTH_SHORT).show();
														finish();
													}
												}, 2000);
										}
									}, 1500);
							}
						});
				}
			}).start();
    }

    // ROOT CHECK (su binary check)
    private boolean checkRoot() {
        Process process = null;
        try {
            process = Runtime.getRuntime().exec("su");
            DataOutputStream os = new DataOutputStream(process.getOutputStream());
            os.writeBytes("exit\n");
            os.flush();
            return process.waitFor() == 0;
        } catch (Exception e) {
            return false;
        } finally {
            if (process != null) {
                try { process.destroy(); } catch (Exception e) {}
            }
        }
    }

    // GAME PROCESS CHECK (Free Fire aur Free Fire Max dono check karega)
    private boolean checkGameProcess() {
        try {
            // Root ke through phone ke saare processes ki list nikaal rahe hain
            Process process = Runtime.getRuntime().exec("su -c ps");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                // Free Fire / Free Fire Max ka package name
                if (line.contains("com.dts.freefireth") || line.contains("com.dts.freefiremax")) {
                    return true;
                }
            }
            process.destroy();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQ) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M
				|| Settings.canDrawOverlays(this)) {
                startPanel();
            } else {
                Toast.makeText(this, "Overlay permission is required", Toast.LENGTH_LONG).show();
            }
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
