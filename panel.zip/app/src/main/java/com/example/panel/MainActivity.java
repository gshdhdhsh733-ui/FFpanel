package com.example.panel;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQ = 10;
    private static final int NOTIF_REQ = 11;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, NOTIF_REQ);
            }
        }

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        layout.setPadding(50, 100, 50, 50);
        layout.setBackgroundColor(0xFF0A0A0A);

        TextView title = new TextView(this);
        title.setText("PRO ROOT MOD");
        title.setTextColor(0xFFE53935); // Red Theme
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        Button start = new Button(this);
        start.setText("START PANEL");
        layout.addView(start);
        start.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) { startPanel(); }
			});

        Button stop = new Button(this);
        stop.setText("STOP PANEL");
        layout.addView(stop);
        stop.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					stopService(new Intent(MainActivity.this, PanelService.class));
					Toast.makeText(MainActivity.this, "Panel stopped", Toast.LENGTH_SHORT).show();
				}
			});

        setContentView(layout);
    }

    private void startPanel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(permission, OVERLAY_REQ);
            return;
        }
        Intent service = new Intent(this, PanelService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
        else startService(service);
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQ) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                startPanel();
            }
        }
    }
}
