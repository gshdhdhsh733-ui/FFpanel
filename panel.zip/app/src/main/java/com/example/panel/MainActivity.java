package com.example.myapp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQ = 10;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        showHome();
    }

    private void showHome() {
        FrameLayout root = new FrameLayout(this);

        // 1. Background Image
        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.bg_main);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(bg, new FrameLayout.LayoutParams(
						 FrameLayout.LayoutParams.MATCH_PARENT,
						 FrameLayout.LayoutParams.MATCH_PARENT));

        // Screen ki height nikaal rahe hain click area set karne ke liye
        int screenHeight = getResources().getDisplayMetrics().heightPixels;

        // 2. Invisible START Button (Screen height ka 39% hissa)
        View invisibleStart = new View(this);
        FrameLayout.LayoutParams startLp = new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.MATCH_PARENT, dp(70)); 
        startLp.gravity = Gravity.TOP;
        startLp.topMargin = (int) (screenHeight * 0.39); 
        invisibleStart.setLayoutParams(startLp);
        invisibleStart.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					startPanel();
				}
			});
        root.addView(invisibleStart);

        // 3. Invisible STOP Button (Screen height ka 49% hissa)
        View invisibleStop = new View(this);
        FrameLayout.LayoutParams stopLp = new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.MATCH_PARENT, dp(70)); 
        stopLp.gravity = Gravity.TOP;
        stopLp.topMargin = (int) (screenHeight * 0.49); 
        invisibleStop.setLayoutParams(stopLp);
        invisibleStop.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					stopService(new Intent(MainActivity.this, PanelService.class));
					Toast.makeText(MainActivity.this, "Panel stopped", Toast.LENGTH_SHORT).show();
				}
			});
        root.addView(invisibleStop);

        setContentView(root);
    }

    private void startPanel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
			&& !Settings.canDrawOverlays(this)) {
            Intent permission = new Intent(
				Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
				Uri.parse("package:" + getPackageName()));
            startActivityForResult(permission, OVERLAY_REQ);
            return;
        }

        Intent service = new Intent(this, PanelService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(service);
        } else {
            startService(service);
        }
        Toast.makeText(this, "Panel started", Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQ) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M
				|| Settings.canDrawOverlays(this)) {
                startPanel();
            } else {
                Toast.makeText(this, "Overlay permission is required",
							   Toast.LENGTH_LONG).show();
            }
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
