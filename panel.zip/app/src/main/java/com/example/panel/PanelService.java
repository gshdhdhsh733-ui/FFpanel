package com.example.panel;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class PanelService extends Service {
    private WindowManager wm;
    private OverlayView overlayView;
    private Handler tickHandler;
    private Runnable tickRunnable;

    private LinearLayout panel;
    private Button showBtn;
    private WindowManager.LayoutParams windowParams, smallParams;

    public static boolean sAimCollider = true, sAimSilent = false, sAimHijack = false;
    public static boolean sIgnoreTeammates = true, sAimLine = false, sShowFov = true;
    public static boolean sEspEnabled = true, sBoxes = true, sLines = true;
    public static int sFovRadius = 350;

    private final int COLOR_BG = 0xFF0F0F11;       
    private final int COLOR_BOX = 0xFF1C1C1E;      
    private final int COLOR_RED = 0xFFE53935;      
    private final int COLOR_TEXT = 0xFFEEEEEE;     
    private final int COLOR_TEXT_DIM = 0xFF888888; 

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        String channelId = "p";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(channelId, "Panel", NotificationManager.IMPORTANCE_LOW));
        }
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) b = new Notification.Builder(this, channelId);
        else b = new Notification.Builder(this);

        startForeground(42, b.setContentTitle("pro root mod Active").setSmallIcon(android.R.drawable.ic_menu_view).build());

        createOverlay();
        createPanel();

        if (EngineClient.attach(this, "com.dts.freefiremax")) {
            tickHandler = new Handler(Looper.getMainLooper());
            tickRunnable = new Runnable() {
                @Override
                public void run() {
                    if (overlayView != null) overlayView.updateTargets(EngineClient.pull());
                    tickHandler.postDelayed(tickRunnable, 16);
                }
            };
            tickHandler.post(tickRunnable);
        } else {
            Toast.makeText(this, "Attach failed! Root needed.", Toast.LENGTH_LONG).show();
        }
    }

    private void createOverlay() {
        overlayView = new OverlayView(this);
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
			PixelFormat.TRANSLUCENT);
        wm.addView(overlayView, lp);
    }

    private GradientDrawable getRoundRect(int color, float radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setColor(color);
        shape.setCornerRadius(radius);
        return shape;
    }

    private void createPanel() {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        windowParams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, 
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        windowParams.gravity = Gravity.TOP | Gravity.START;
        windowParams.x = 100; windowParams.y = 150;

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setBackground(getRoundRect(COLOR_BG, 25f));
        panel.setPadding(15, 15, 15, 15);

        LinearLayout sidebar = new LinearLayout(this);
        sidebar.setOrientation(LinearLayout.VERTICAL);
        sidebar.setGravity(Gravity.CENTER_HORIZONTAL);
        sidebar.setPadding(10, 10, 10, 10);

        sidebar.addView(createTab("Aim", "🎯", true));
        sidebar.addView(createTab("Visuals", "👁", false));
        sidebar.addView(createTab("Misc", "⚡", false));

        View divider = new View(this);
        divider.setBackgroundColor(0xFF333333);
        LinearLayout.LayoutParams divParams = new LinearLayout.LayoutParams(2, LinearLayout.LayoutParams.MATCH_PARENT);
        divParams.setMargins(10, 0, 10, 0);
        divider.setLayoutParams(divParams);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(15, 5, 15, 5);
        content.setLayoutParams(new LinearLayout.LayoutParams(750, LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, 20);

        TextView title = new TextView(this);
        title.setText("🔴 PRO ROOT MOD"); 
        title.setTextColor(COLOR_RED);
        title.setTextSize(16f);
        title.setTypeface(null, Typeface.BOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView closeBtn = new TextView(this);
        closeBtn.setText("✖");
        closeBtn.setTextColor(COLOR_RED);
        closeBtn.setTextSize(20f);
        closeBtn.setPadding(20, 0, 10, 0);
        closeBtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					wm.removeView(panel);
					showSmallButton();
				}
			});

        header.addView(title);
        header.addView(closeBtn);

        header.setOnTouchListener(new View.OnTouchListener() {
				int initialX, initialY;
				float initialTouchX, initialTouchY;
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							initialX = windowParams.x; initialY = windowParams.y;
							initialTouchX = event.getRawX(); initialTouchY = event.getRawY();
							return true;
						case MotionEvent.ACTION_MOVE:
							windowParams.x = initialX + (int) (event.getRawX() - initialTouchX);
							windowParams.y = initialY + (int) (event.getRawY() - initialTouchY);
							wm.updateViewLayout(panel, windowParams);
							return true;
					}
					return false;
				}
			});
        content.addView(header);

        LinearLayout columns = new LinearLayout(this);
        columns.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout leftCol = new LinearLayout(this);
        leftCol.setOrientation(LinearLayout.VERTICAL);
        leftCol.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        leftCol.addView(createSectionTitle("AIM ASSIST"));
        leftCol.addView(createToggleRow("Aim Collider", sAimCollider, 0)); 
        leftCol.addView(createToggleRow("Aim Silent (Risk)", sAimSilent, -1));

        LinearLayout rightCol = new LinearLayout(this);
        rightCol.setOrientation(LinearLayout.VERTICAL);
        rightCol.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        rightCol.setPadding(20, 0, 0, 0);
        rightCol.addView(createSectionTitle("SETTINGS"));
        rightCol.addView(createToggleRow("Ignore Teammates", sIgnoreTeammates, 4)); 
        rightCol.addView(createToggleRow("Aim Line", sAimLine, 3)); 
        rightCol.addView(createToggleRow("Show ESP Box", sBoxes, 1)); 
        rightCol.addView(createSlider("Aim FOV Range", sFovRadius));

        columns.addView(leftCol);
        columns.addView(rightCol);
        content.addView(columns);

        panel.addView(sidebar);
        panel.addView(divider);
        panel.addView(content);

        wm.addView(panel, windowParams);
    }

    private LinearLayout createTab(String name, String icon, boolean isActive) {
        LinearLayout tab = new LinearLayout(this);
        tab.setOrientation(LinearLayout.VERTICAL);
        tab.setGravity(Gravity.CENTER);
        tab.setPadding(10, 25, 10, 25);

        TextView iconTv = new TextView(this);
        iconTv.setText(icon); iconTv.setTextSize(20f);
        iconTv.setTextColor(isActive ? COLOR_RED : COLOR_TEXT_DIM);
        iconTv.setGravity(Gravity.CENTER);

        TextView text = new TextView(this);
        text.setText(name); text.setTextSize(12f);
        text.setTypeface(null, isActive ? Typeface.BOLD : Typeface.NORMAL);
        text.setTextColor(isActive ? COLOR_RED : COLOR_TEXT_DIM);

        tab.addView(iconTv); tab.addView(text);
        return tab;
    }

    private TextView createSectionTitle(String text) {
        TextView tv = new TextView(this);
        tv.setText(text); tv.setTextColor(COLOR_RED); tv.setTextSize(14f);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setPadding(0, 0, 0, 15);
        return tv;
    }

    private LinearLayout createToggleRow(String label, boolean initial, final int slot) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(getRoundRect(COLOR_BOX, 15f));
        row.setPadding(20, 15, 20, 15);

        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.setMargins(0, 0, 0, 10);
        row.setLayoutParams(rowParams);

        TextView text = new TextView(this);
        text.setText(label); text.setTextColor(COLOR_TEXT); text.setTextSize(13f);
        text.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Switch toggle = new Switch(this);
        toggle.setChecked(initial);
        toggle.setButtonTintList(new ColorStateList(
									 new int[][]{ new int[]{android.R.attr.state_checked}, new int[]{} },
									 new int[]{ COLOR_RED, 0xFF555555 }
								 ));

        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if (slot >= 0) EngineClient.flag(slot, isChecked);
					if (slot == 1) sBoxes = isChecked;
					if (slot == 3) sAimLine = isChecked;
					if (slot == 4) sIgnoreTeammates = isChecked;
				}
			});

        row.addView(text); row.addView(toggle);
        return row;
    }

    private LinearLayout createSlider(String label, int initial) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(0, 10, 0, 10);

        TextView tv = new TextView(this);
        tv.setText(label); tv.setTextColor(COLOR_TEXT_DIM); tv.setTextSize(12f);
        tv.setPadding(10, 0, 0, 5);

        SeekBar sb = new SeekBar(this);
        sb.setMax(800); sb.setProgress(initial);
        sb.setProgressTintList(ColorStateList.valueOf(COLOR_RED));

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { sFovRadius = progress; }
				@Override public void onStartTrackingTouch(SeekBar seekBar) {}
				@Override public void onStopTrackingTouch(SeekBar seekBar) {}
			});

        layout.addView(tv); layout.addView(sb);
        return layout;
    }

    private void showSmallButton() {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        smallParams = new WindowManager.LayoutParams(150, 150, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        smallParams.gravity = Gravity.TOP | Gravity.START;
        smallParams.x = 50; smallParams.y = 200;

        showBtn = new Button(this);
        showBtn.setText("MENU");
        showBtn.setTextSize(10f);
        showBtn.setBackgroundColor(COLOR_RED);
        showBtn.setTextColor(Color.WHITE);

        showBtn.setOnTouchListener(new View.OnTouchListener() {
				int initialX, initialY; float initialTouchX, initialTouchY; boolean isDragging = false;
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							initialX = smallParams.x; initialY = smallParams.y;
							initialTouchX = event.getRawX(); initialTouchY = event.getRawY();
							isDragging = false; return true;
						case MotionEvent.ACTION_MOVE:
							if (Math.abs(event.getRawX() - initialTouchX) > 10 || Math.abs(event.getRawY() - initialTouchY) > 10) {
								isDragging = true;
								smallParams.x = initialX + (int) (event.getRawX() - initialTouchX);
								smallParams.y = initialY + (int) (event.getRawY() - initialTouchY);
								wm.updateViewLayout(showBtn, smallParams);
							}
							return true;
						case MotionEvent.ACTION_UP:
							if (!isDragging) {
								wm.removeView(showBtn);
								windowParams.x = smallParams.x; windowParams.y = smallParams.y;
								wm.addView(panel, windowParams);
							}
							return true;
					}
					return false;
				}
			});
        wm.addView(showBtn, smallParams);
    }

    @Override
    public void onDestroy() {
        if (tickHandler != null) tickHandler.removeCallbacks(tickRunnable);
        EngineClient.shutdown();
        if (overlayView != null) wm.removeView(overlayView);
        if (panel != null && panel.getParent() != null) wm.removeView(panel);
        if (showBtn != null && showBtn.getParent() != null) wm.removeView(showBtn);
        super.onDestroy();
    }
}
