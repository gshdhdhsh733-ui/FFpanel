package com.example.myapp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

public class PanelService extends Service {
    private static final String CHANNEL_ID = "ff_panel";
    private static final int NOTIFICATION_ID = 42;

    private WindowManager windowManager;
    private View rootView; 
    private WindowManager.LayoutParams windowParams;

    private int downX, downY, startX, startY;

    public static boolean espEnabled = true;
    public static boolean boxESP = true;
    public static boolean snapLine = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        startInForeground();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
			&& !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        createPanel();
    }

    private void startInForeground() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
				CHANNEL_ID, "Floating panel", NotificationManager.IMPORTANCE_LOW);
            manager.createNotificationChannel(channel);
        }

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        Notification notification = builder
			.setContentTitle("Pro Mode Root")
			.setContentText("Floating panel is active")
			.setSmallIcon(android.R.drawable.ic_menu_view)
			.setOngoing(true)
			.build();

        startForeground(NOTIFICATION_ID, notification);
    }

    private void createPanel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
			? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
			: WindowManager.LayoutParams.TYPE_PHONE;

        // Panel ka Size Fix kiya (Width 320, Height 180)
        windowParams = new WindowManager.LayoutParams(
			dp(320), 
			dp(180),
			type,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
			PixelFormat.TRANSLUCENT);
        windowParams.gravity = Gravity.TOP | Gravity.START;
        windowParams.x = dp(20);
        windowParams.y = dp(100);

        final FrameLayout rootFrame = new FrameLayout(this);
        this.rootView = rootFrame;

        // 1. Background Image (bg_panel.png)
        ImageView bgImage = new ImageView(this);
        bgImage.setImageResource(R.drawable.bg_panel);
        // CENTER_CROP stretch hone se rokega
        bgImage.setScaleType(ImageView.ScaleType.CENTER_CROP); 

        // Drag feature (Background ko pakad kar move karne ke liye)
        bgImage.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					return dragPanel(v, event);
				}
			});

        rootFrame.addView(bgImage, new FrameLayout.LayoutParams(
							  FrameLayout.LayoutParams.MATCH_PARENT,
							  FrameLayout.LayoutParams.MATCH_PARENT));

        // 2. TRANSPARENT CLICK ZONES (Perfectly Aligned)

        // Close Button (Top Right 'X')
        View closeZone = new View(this);
        FrameLayout.LayoutParams closeLp = new FrameLayout.LayoutParams(dp(35), dp(35));
        closeLp.gravity = Gravity.TOP | Gravity.END;
        closeLp.topMargin = dp(10);
        closeLp.rightMargin = dp(10);
        closeZone.setLayoutParams(closeLp);
        closeZone.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					stopSelf();
				}
			});
        rootFrame.addView(closeZone);

        // Master Toggle Zone (Pehli line)
        View masterZone = new View(this);
        FrameLayout.LayoutParams masterLp = new FrameLayout.LayoutParams(dp(60), dp(30));
        masterLp.gravity = Gravity.TOP | Gravity.END;
        masterLp.topMargin = dp(75);
        masterLp.rightMargin = dp(15);
        masterZone.setLayoutParams(masterLp);
        masterZone.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					espEnabled = !espEnabled;
					Toast.makeText(PanelService.this, "Master: " + espEnabled, Toast.LENGTH_SHORT).show();
				}
			});
        rootFrame.addView(masterZone);

        // ESP Box Toggle Zone (Doosri line)
        View espZone = new View(this);
        FrameLayout.LayoutParams espLp = new FrameLayout.LayoutParams(dp(60), dp(30));
        espLp.gravity = Gravity.TOP | Gravity.END;
        espLp.topMargin = dp(110);
        espLp.rightMargin = dp(15);
        espZone.setLayoutParams(espLp);
        espZone.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					boxESP = !boxESP;
					Toast.makeText(PanelService.this, "ESP Box: " + boxESP, Toast.LENGTH_SHORT).show();
				}
			});
        rootFrame.addView(espZone);

        // Snap Line Toggle Zone (Teesri line)
        View snapZone = new View(this);
        FrameLayout.LayoutParams snapLp = new FrameLayout.LayoutParams(dp(60), dp(30));
        snapLp.gravity = Gravity.TOP | Gravity.END;
        snapLp.topMargin = dp(145);
        snapLp.rightMargin = dp(15);
        snapZone.setLayoutParams(snapLp);
        snapZone.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					snapLine = !snapLine;
					Toast.makeText(PanelService.this, "Snap Line: " + snapLine, Toast.LENGTH_SHORT).show();
				}
			});
        rootFrame.addView(snapZone);

        try {
            windowManager.addView(rootFrame, windowParams);
        } catch (Exception e) {
            Toast.makeText(this, "Overlay failed", Toast.LENGTH_SHORT).show();
            stopSelf();
        }
    }

    private boolean dragPanel(View view, MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startX = windowParams.x;
                startY = windowParams.y;
                downX = (int) event.getRawX();
                downY = (int) event.getRawY();
                return true;
            case MotionEvent.ACTION_MOVE:
                windowParams.x = startX + (int) event.getRawX() - downX;
                windowParams.y = startY + (int) event.getRawY() - downY;
                if (rootView != null && rootView.isAttachedToWindow()) {
                    windowManager.updateViewLayout(rootView, windowParams);
                }
                return true;
            default:
                return false;
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onDestroy() {
        if (rootView != null && windowManager != null && rootView.isAttachedToWindow()) {
            try {
                windowManager.removeView(rootView);
            } catch (RuntimeException ignored) { }
        }
        rootView = null;
        stopForeground(true);
        super.onDestroy();
    }
}
