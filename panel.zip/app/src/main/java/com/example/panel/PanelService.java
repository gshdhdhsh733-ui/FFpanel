package com.example.myapp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class PanelService extends Service {
    private static final String CHANNEL_ID = "ff_panel";
    private static final int NOTIFICATION_ID = 42;

    private WindowManager windowManager;
    private LinearLayout panel;
    private View rootView; 
    private WindowManager.LayoutParams windowParams;

    private int downX, downY, startX, startY;

    public static boolean espEnabled = true;
    public static boolean boxESP = true;
    public static boolean snapLine = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        startInForeground();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
			&& !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        createPanel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    private void startInForeground() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
				CHANNEL_ID, "Floating panel", NotificationManager.IMPORTANCE_LOW);
            manager.createNotificationChannel(channel);
        }

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        Notification notification = builder
			.setContentTitle("Pro Mode Root")
			.setContentText("Floating panel is active")
			.setSmallIcon(android.R.drawable.ic_menu_view)
			.setOngoing(true)
			.build();

        startForeground(NOTIFICATION_ID, notification);
    }

    private void createPanel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
			? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
			: WindowManager.LayoutParams.TYPE_PHONE;

        windowParams = new WindowManager.LayoutParams(
			dp(400), 
			WindowManager.LayoutParams.WRAP_CONTENT,
			type,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
			PixelFormat.TRANSLUCENT);
        windowParams.gravity = Gravity.TOP | Gravity.START;
        windowParams.x = dp(10);
        windowParams.y = dp(100);

        final FrameLayout rootFrame = new FrameLayout(this);
        this.rootView = rootFrame;

        ImageView bgImage = new ImageView(this);
        bgImage.setImageResource(R.drawable.bg_panel);
        bgImage.setScaleType(ImageView.ScaleType.FIT_XY);

        bgImage.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					return dragPanel(v, event);
				}
			});

        rootFrame.addView(bgImage, new FrameLayout.LayoutParams(
							  FrameLayout.LayoutParams.MATCH_PARENT,
							  FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout topRightLayout = new LinearLayout(this);
        topRightLayout.setOrientation(LinearLayout.HORIZONTAL);
        FrameLayout.LayoutParams trLp = new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.WRAP_CONTENT, 
			FrameLayout.LayoutParams.WRAP_CONTENT);
        trLp.gravity = Gravity.TOP | Gravity.END;
        trLp.topMargin = dp(20);
        trLp.rightMargin = dp(20);
        topRightLayout.setLayoutParams(trLp);

        ImageView refreshBtn = new ImageView(this);
        refreshBtn.setImageResource(R.drawable.icon_refresh);
        LinearLayout.LayoutParams refLp = new LinearLayout.LayoutParams(dp(25), dp(25));
        refLp.rightMargin = dp(10);
        refreshBtn.setLayoutParams(refLp);
        refreshBtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					Toast.makeText(PanelService.this, "Refreshed", Toast.LENGTH_SHORT).show();
				}
			});

        ImageView closeBtn = new ImageView(this);
        closeBtn.setImageResource(R.drawable.icon_close);
        closeBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(25), dp(25)));
        closeBtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					stopSelf();
				}
			});

        topRightLayout.addView(refreshBtn);
        topRightLayout.addView(closeBtn);
        rootFrame.addView(topRightLayout);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(150), dp(80), dp(20), dp(20)); 

        ImageView hideBtn = new ImageView(this);
        hideBtn.setImageResource(R.drawable.btn_hide);
        LinearLayout.LayoutParams hideLp = new LinearLayout.LayoutParams(dp(90), dp(32));
        hideLp.gravity = Gravity.END;
        hideLp.bottomMargin = dp(30);
        hideBtn.setLayoutParams(hideLp);
        hideBtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					rootFrame.setVisibility(View.GONE);
					Toast.makeText(PanelService.this, "Panel Hidden", Toast.LENGTH_SHORT).show();
				}
			});
        panel.addView(hideBtn);

        addCustomToggle(panel, "Master", espEnabled, new ToggleAction() {
				@Override public void set(boolean enabled) { espEnabled = enabled; }
			});
        addCustomToggle(panel, "ESP Box", boxESP, new ToggleAction() {
				@Override public void set(boolean enabled) { boxESP = enabled; }
			});
        addCustomToggle(panel, "Snap Line", snapLine, new ToggleAction() {
				@Override public void set(boolean enabled) { snapLine = enabled; }
			});

        rootFrame.addView(panel);

        LinearLayout bottomLeftLayout = new LinearLayout(this);
        bottomLeftLayout.setOrientation(LinearLayout.VERTICAL);
        bottomLeftLayout.setGravity(Gravity.BOTTOM);

        FrameLayout.LayoutParams bottomLp = new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.WRAP_CONTENT, 
			FrameLayout.LayoutParams.MATCH_PARENT);
        bottomLp.gravity = Gravity.BOTTOM | Gravity.START;
        bottomLp.leftMargin = dp(20);
        bottomLp.bottomMargin = dp(20);
        bottomLeftLayout.setLayoutParams(bottomLp);

        ImageView visualsBtn = new ImageView(this);
        visualsBtn.setImageResource(R.drawable.btn_visuals);
        LinearLayout.LayoutParams visLp = new LinearLayout.LayoutParams(dp(130), dp(35));
        visLp.bottomMargin = dp(15);
        visualsBtn.setLayoutParams(visLp);
        bottomLeftLayout.addView(visualsBtn);

        ImageView v1Badge = new ImageView(this);
        v1Badge.setImageResource(R.drawable.v1_badge);
        v1Badge.setLayoutParams(new LinearLayout.LayoutParams(dp(80), dp(35)));
        bottomLeftLayout.addView(v1Badge);

        rootFrame.addView(bottomLeftLayout);

        try {
            windowManager.addView(rootFrame, windowParams);
        } catch (Exception e) {
            Toast.makeText(this, "Overlay failed", Toast.LENGTH_SHORT).show();
            stopSelf();
        }
    }

    private interface ToggleAction {
        void set(boolean enabled);
    }

    private void addCustomToggle(LinearLayout parent, String labelText, boolean initialState, final ToggleAction action) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, dp(10));

        TextView label = new TextView(this);
        label.setText(labelText);
        label.setTextColor(0xFFFFFFFF);
        label.setTextSize(15);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        label.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        final ImageView toggleView = new ImageView(this);
        LinearLayout.LayoutParams toggleLp = new LinearLayout.LayoutParams(dp(65), dp(32));
        toggleView.setLayoutParams(toggleLp);
        toggleView.setScaleType(ImageView.ScaleType.FIT_CENTER);

        toggleView.setImageResource(initialState ? R.drawable.toggle_on : R.drawable.toggle_off);
        final boolean[] currentState = {initialState};

        toggleView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					currentState[0] = !currentState[0];
					toggleView.setImageResource(currentState[0] ? R.drawable.toggle_on : R.drawable.toggle_off);
					action.set(currentState[0]); 
				}
			});

        row.addView(label);
        row.addView(toggleView);
        parent.addView(row);
    }

    private boolean dragPanel(View view, MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startX = windowParams.x;
                startY = windowParams.y;
                downX = (int) event.getRawX();
                downY = (int) event.getRawY();
                return true;
            case MotionEvent.ACTION_MOVE:
                windowParams.x = startX + (int) event.getRawX() - downX;
                windowParams.y = startY + (int) event.getRawY() - downY;
                if (rootView != null && rootView.isAttachedToWindow()) {
                    windowManager.updateViewLayout(rootView, windowParams);
                }
                return true;
            default:
                return false;
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onDestroy() {
        if (rootView != null && windowManager != null && rootView.isAttachedToWindow()) {
            try {
                windowManager.removeView(rootView);
            } catch (RuntimeException ignored) { }
        }
        rootView = null;
        panel = null;
        stopForeground(true);
        super.onDestroy();
    }
}
