package com.example.myapp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

public class PanelService extends Service {
    private static final String CHANNEL_ID = "ff_panel";
    private static final int NOTIFICATION_ID = 42;

    private WindowManager windowManager;
    private FrameLayout mainPanel;
    private WindowManager.LayoutParams mainParams;

    private ImageView miniIcon;
    private WindowManager.LayoutParams miniParams;

    private int downX, downY, startX, startY;

    public static boolean espEnabled = true;
    public static boolean boxESP = true;
    public static boolean snapLine = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        startInForeground();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
			&& !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        initParams();
        createMainPanel();
        createMiniIcon();

        try {
            windowManager.addView(mainPanel, mainParams);
            // Panel open hone ki animation
            mainPanel.setScaleX(0f);
            mainPanel.setScaleY(0f);
            mainPanel.animate().scaleX(1f).scaleY(1f).setDuration(200).start();
        } catch (Exception e) {
            stopSelf();
        }
    }

    private void initParams() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
			? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
			: WindowManager.LayoutParams.TYPE_PHONE;

        mainParams = new WindowManager.LayoutParams(
			dp(320), dp(180), type,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
			PixelFormat.TRANSLUCENT);
        mainParams.gravity = Gravity.TOP | Gravity.START;
        mainParams.x = dp(20);
        mainParams.y = dp(100);

        miniParams = new WindowManager.LayoutParams(
			dp(50), dp(50), type,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
			PixelFormat.TRANSLUCENT);
        miniParams.gravity = Gravity.TOP | Gravity.START;
        miniParams.x = dp(20);
        miniParams.y = dp(100);
    }

    private void startInForeground() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
				CHANNEL_ID, "Floating panel", NotificationManager.IMPORTANCE_LOW);
            manager.createNotificationChannel(channel);
        }

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        Notification notification = builder
			.setContentTitle("Pro Mode Root")
			.setContentText("Floating panel is active")
			.setSmallIcon(android.R.drawable.ic_menu_view)
			.setOngoing(true)
			.build();

        startForeground(NOTIFICATION_ID, notification);
    }

    private void createMainPanel() {
        mainPanel = new FrameLayout(this);

        ImageView bgImage = new ImageView(this);
        bgImage.setImageResource(R.drawable.bg_panel);
        bgImage.setScaleType(ImageView.ScaleType.CENTER_CROP);

        bgImage.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					return dragPanel(v, event, mainParams, mainPanel);
				}
			});

        mainPanel.addView(bgImage, new FrameLayout.LayoutParams(
							  FrameLayout.LayoutParams.MATCH_PARENT,
							  FrameLayout.LayoutParams.MATCH_PARENT));

        // Close Button Zone
        View closeZone = new View(this);
        FrameLayout.LayoutParams closeLp = new FrameLayout.LayoutParams(dp(30), dp(30));
        closeLp.gravity = Gravity.TOP | Gravity.END;
        closeLp.topMargin = dp(10);
        closeLp.rightMargin = dp(10);
        closeZone.setLayoutParams(closeLp);
        closeZone.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					stopSelf();
				}
			});
        mainPanel.addView(closeZone);

        // HIDE Button Zone (With Animation)
        View hideZone = new View(this);
        FrameLayout.LayoutParams hideLp = new FrameLayout.LayoutParams(dp(80), dp(30));
        hideLp.gravity = Gravity.TOP | Gravity.END;
        hideLp.topMargin = dp(42);
        hideLp.rightMargin = dp(15);
        hideZone.setLayoutParams(hideLp);
        hideZone.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// Zoom out animation
					mainPanel.animate().scaleX(0f).scaleY(0f).setDuration(200).withEndAction(new Runnable() {
							@Override
							public void run() {
								windowManager.removeView(mainPanel);
								miniParams.x = mainParams.x;
								miniParams.y = mainParams.y;
								windowManager.addView(miniIcon, miniParams);

								// Mini icon zoom in animation
								miniIcon.setScaleX(0f);
								miniIcon.setScaleY(0f);
								miniIcon.animate().scaleX(1f).scaleY(1f).setDuration(200).start();
							}
						}).start();
				}
			});
        mainPanel.addView(hideZone);

        // Toggles (With Bounce Animation)
        final ImageView masterToggle = createToggle(espEnabled, dp(78));
        masterToggle.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					espEnabled = !espEnabled;
					animateToggle(masterToggle, espEnabled);
				}
			});
        mainPanel.addView(masterToggle);

        final ImageView espToggle = createToggle(boxESP, dp(113));
        espToggle.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					boxESP = !boxESP;
					animateToggle(espToggle, boxESP);
				}
			});
        mainPanel.addView(espToggle);

        final ImageView snapToggle = createToggle(snapLine, dp(148));
        snapToggle.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					snapLine = !snapLine;
					animateToggle(snapToggle, snapLine);
				}
			});
        mainPanel.addView(snapToggle);
    }

    // Toggle Animation Function (Bounce effect)
    private void animateToggle(final ImageView toggleView, final boolean isOn) {
        toggleView.animate().scaleX(0.7f).scaleY(0.7f).setDuration(100).withEndAction(new Runnable() {
				@Override
				public void run() {
					toggleView.setImageResource(isOn ? R.drawable.toggle_on : R.drawable.toggle_off);
					toggleView.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
				}
			}).start();
    }

    private ImageView createToggle(boolean initialState, int topMargin) {
        ImageView toggle = new ImageView(this);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(60), dp(25));
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.topMargin = topMargin;
        lp.rightMargin = dp(15);
        toggle.setLayoutParams(lp);
        toggle.setScaleType(ImageView.ScaleType.FIT_CENTER);
        toggle.setImageResource(initialState ? R.drawable.toggle_on : R.drawable.toggle_off);
        return toggle;
    }

    private void createMiniIcon() {
        miniIcon = new ImageView(this);
        miniIcon.setImageResource(R.drawable.icon_target);
        miniIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);

        miniIcon.setOnTouchListener(new View.OnTouchListener() {
				private long downTime;
				private boolean isDragging = false;

				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							startX = miniParams.x;
							startY = miniParams.y;
							downX = (int) event.getRawX();
							downY = (int) event.getRawY();
							downTime = System.currentTimeMillis();
							isDragging = false;
							return true;
						case MotionEvent.ACTION_MOVE:
							int dx = (int) event.getRawX() - downX;
							int dy = (int) event.getRawY() - downY;
							if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
								isDragging = true;
								miniParams.x = startX + dx;
								miniParams.y = startY + dy;
								windowManager.updateViewLayout(miniIcon, miniParams);
							}
							return true;
						case MotionEvent.ACTION_UP:
							if (!isDragging && System.currentTimeMillis() - downTime < 200) {
								// Icon ko zoom out karo aur panel ko zoom in karo
								miniIcon.animate().scaleX(0f).scaleY(0f).setDuration(200).withEndAction(new Runnable() {
										@Override
										public void run() {
											windowManager.removeView(miniIcon);
											mainParams.x = miniParams.x;
											mainParams.y = miniParams.y;
											windowManager.addView(mainPanel, mainParams);

											mainPanel.setScaleX(0f);
											mainPanel.setScaleY(0f);
											mainPanel.animate().scaleX(1f).scaleY(1f).setDuration(200).start();
										}
									}).start();
							}
							return true;
					}
					return false;
				}
			});
    }

    private boolean dragPanel(View view, MotionEvent event, WindowManager.LayoutParams params, View panelToUpdate) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startX = params.x;
                startY = params.y;
                downX = (int) event.getRawX();
                downY = (int) event.getRawY();
                return true;
            case MotionEvent.ACTION_MOVE:
                params.x = startX + (int) event.getRawX() - downX;
                params.y = startY + (int) event.getRawY() - downY;
                if (panelToUpdate != null && panelToUpdate.isAttachedToWindow()) {
                    windowManager.updateViewLayout(panelToUpdate, params);
                }
                return true;
            default:
                return false;
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onDestroy() {
        try {
            if (mainPanel != null && mainPanel.isAttachedToWindow()) windowManager.removeView(mainPanel);
            if (miniIcon != null && miniIcon.isAttachedToWindow()) windowManager.removeView(miniIcon);
        } catch (RuntimeException ignored) { }
        stopForeground(true);
        super.onDestroy();
    }
}
