#include "esp.h"
#include <cmath>
#include <cstring>

namespace ff {
void multiply_matrices(float* out, const float* a, const float* b) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            out[i * 4 + j] = 0;
            for (int k = 0; k < 4; k++) out[i * 4 + j] += a[i * 4 + k] * b[k * 4 + j];
        }
    }
}
ScreenPoint ESP::world_to_screen(const Vec3& w, const float* m, int sw, int sh) {
    float x = w.x*m[0] + w.y*m[4] + w.z*m[8] + m[12];
    float y = w.x*m[1] + w.y*m[5] + w.z*m[9] + m[13];
    float w_= w.x*m[3] + w.y*m[7] + w.z*m[11] + m[15];
    if (w_ < 0.01f) return {0,0,false};
    return { (sw*0.5f)*(1 + x/w_), (sh*0.5f)*(1 - y/w_), true };
}
void ESP::refresh(CheatEngine& engine) {
    projected_.clear();
    if (!engine.alive() || !enabled_) return;

    static const uintptr_t kGameFacade = 0xA86D8D8;     
    static const uintptr_t kLocalPlayerPtr = 0xA86F580; 
    static const uintptr_t kHealthOffset = 0x1E4;       
    static const uintptr_t kTeamOffset = 0xC8;          
    static const uintptr_t kTransformOffset = 0xE8;     
    static const uintptr_t kViewMatrixPtr = 0xB0F7948;  
    static const uintptr_t kProjMatrixPtr = 0xB0F7958;  

    uintptr_t view_ptr = engine.read<uintptr_t>(engine.module_base() + kViewMatrixPtr);
    uintptr_t proj_ptr = engine.read<uintptr_t>(engine.module_base() + kProjMatrixPtr);
    float viewMatrix[16]{}, projMatrix[16]{}, vpMatrix[16]{};
    
    if (view_ptr && proj_ptr) {
        engine.read(view_ptr, viewMatrix, sizeof(viewMatrix));
        engine.read(proj_ptr, projMatrix, sizeof(projMatrix));
        multiply_matrices(vpMatrix, viewMatrix, projMatrix);
    } else return;

    uintptr_t local_player = engine.read<uintptr_t>(engine.module_base() + kLocalPlayerPtr);
    int my_team = 0;
    if (local_player) my_team = engine.read<int>(local_player + kTeamOffset);

    uintptr_t facade = engine.module_base() + kGameFacade;
    uintptr_t game = engine.read<uintptr_t>(facade + 0x0); 
    if (!game) return;
    uintptr_t matchGame = engine.read<uintptr_t>(game + 0x8); 
    if (!matchGame) return;
    
    uintptr_t dict = matchGame + 0x8; 
    uintptr_t entries = engine.read<uintptr_t>(dict + 0x18);
    int count = engine.read<int>(dict + 0x20);
    if (!entries || count <= 0 || count > 200) return;

    for (int i = 0; i < count; ++i) {
        uintptr_t entry = entries + 0x20 + (i * 0x18);
        uintptr_t pawn = engine.read<uintptr_t>(entry + 0x10); 
        if (!pawn || pawn == local_player) continue;

        float hp = engine.read<float>(pawn + kHealthOffset);
        if (hp <= 0 || hp > 2000) continue; 

        int team = engine.read<int>(pawn + kTeamOffset);
        if (ignore_teammates_ && team == my_team) continue;

        uintptr_t transform = engine.read<uintptr_t>(pawn + kTransformOffset);
        if (!transform) continue;

        Vec3 pos;
        pos.x = engine.read<float>(transform + 0x38);
        pos.y = engine.read<float>(transform + 0x3C);
        pos.z = engine.read<float>(transform + 0x40);

        Vec3 head = { pos.x, pos.y + 1.6f, pos.z }; 
        ScreenPoint sp = world_to_screen(head, vpMatrix, 1080, 2400);
        if (sp.visible) projected_.push_back(sp);
    }
}
void ESP::tick(CheatEngine& engine) { refresh(engine); }
}
