#pragma once
#include <cstdint>
#include <string>
namespace ff {
class CheatEngine {
public:
    bool attach(const std::string& pkg);
    void detach();
    bool read(uintptr_t addr, void* buf, size_t size);
    template <typename T> T read(uintptr_t addr) { T value{}; read(addr, &value, sizeof(T)); return value; }
    uintptr_t module_base() const { return info_.base; }
    bool alive() const;
private:
    struct { int pid; uintptr_t base; } info_{-1, 0};
    int mem_fd_ = -1;
    bool attached_ = false;
};
}
