#pragma once
#include <cstdint>
namespace ffd {
enum Cmd : uint32_t { CMD_OPEN=1, CMD_FLAG=2, CMD_RATE=3, CMD_PULL=4, CMD_CLOSE=5 };
struct Header { uint32_t cmd; uint32_t len; };
struct FlagPayload { int32_t slot; int32_t on; };
struct RatePayload { int32_t on; float mult; };
static const char* SOCK_PATH = "/data/local/tmp/ffd.sock";
}
