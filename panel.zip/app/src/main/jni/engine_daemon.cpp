#include "daemon_proto.h"
#include "cheat_engine.h"
#include "esp.h"
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cstring>
#include <vector>
#include <android/log.h>

using namespace ffd;
static ff::CheatEngine g_engine;
static ff::ESP g_esp;

static bool send_all(int fd, const void* buf, size_t n) {
    const char* p = (const char*)buf;
    while (n) { ssize_t k = send(fd, p, n, 0); if (k <= 0) return false; p += k; n -= k; }
    return true;
}
static bool recv_all(int fd, void* buf, size_t n) {
    char* p = (char*)buf;
    while (n) { ssize_t k = recv(fd, p, n, 0); if (k <= 0) return false; p += k; n -= k; }
    return true;
}
static void reply_int(int fd, int32_t v) { send_all(fd, &v, sizeof(v)); }

int main(int, char**) {
    unlink(SOCK_PATH);
    int srv = socket(AF_UNIX, SOCK_STREAM, 0);
    if (srv < 0) return 1;
    sockaddr_un addr{}; addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, SOCK_PATH, sizeof(addr.sun_path) - 1);
    if (bind(srv, (sockaddr*)&addr, sizeof(addr)) < 0) return 1;
    chmod(SOCK_PATH, 0666);
    if (listen(srv, 1) < 0) return 1;
    
    while (true) {
        int cli = accept(srv, nullptr, nullptr);
        if (cli < 0) continue;
        while (true) {
            Header h{};
            if (!recv_all(cli, &h, sizeof(h))) break;
            if (h.cmd == CMD_OPEN) {
                char pkg[256] = {};
                recv_all(cli, pkg, h.len > 255 ? 255 : h.len);
                reply_int(cli, g_engine.attach(pkg) ? 1 : 0);
            } else if (h.cmd == CMD_FLAG) {
                FlagPayload p{}; recv_all(cli, &p, sizeof(p));
                if (p.slot == 0) g_esp.set_master(p.on);
                if (p.slot == 1) g_esp.set_box(p.on);
                if (p.slot == 3) g_esp.set_line(p.on);
                if (p.slot == 4) g_esp.set_name(p.on);
                reply_int(cli, 1);
            } else if (h.cmd == CMD_PULL) {
                g_esp.tick(g_engine);
                const auto& pts = g_esp.projected();
                uint32_t count = (uint32_t)(pts.size() * 2);
                send_all(cli, &count, sizeof(count));
                if (count > 0) {
                    std::vector<float> flat;
                    for (auto& p : pts) { flat.push_back(p.x); flat.push_back(p.y); }
                    send_all(cli, flat.data(), count * sizeof(float));
                }
            } else if (h.cmd == CMD_CLOSE) {
                g_engine.detach(); reply_int(cli, 1); break;
            }
        }
        close(cli);
    }
    return 0;
}
