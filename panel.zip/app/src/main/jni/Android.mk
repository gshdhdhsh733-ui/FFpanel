LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := engine_daemon
LOCAL_SRC_FILES := engine_daemon.cpp cheat_engine.cpp esp.cpp
LOCAL_LDLIBS := -llog
include $(BUILD_EXECUTABLE)
