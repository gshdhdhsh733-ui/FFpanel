#pragma once
#include "cheat_engine.h"
#include <vector>

namespace ff {
struct Vec3 { float x, y, z; };
struct ScreenPoint { float x, y; bool visible; };

class ESP {
public:
    void tick(CheatEngine& engine);
    const std::vector<ScreenPoint>& projected() const { return projected_; }
    void set_master(bool v) { enabled_ = v; }
    void set_box(bool v) { box_ = v; }
    void set_line(bool v) { line_ = v; }
    void set_name(bool v) { name_ = v; }

private:
    bool enabled_ = true, box_ = true, line_ = false, name_ = true;
    std::vector<ScreenPoint> projected_;
    void refresh(CheatEngine& engine);
    // Yahan Vec3 ki jagah ScreenPoint kar diya gaya hai
    ScreenPoint world_to_screen(const Vec3& w, const float* m, int sw, int sh);
};
}
